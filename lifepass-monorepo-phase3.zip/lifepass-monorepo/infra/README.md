# Infrastructure

This directory is intended for infrastructure as code (IaC) configurations, such as Terraform scripts for deploying resources, CI/CD pipelines, and secret management definitions.

At present this is a placeholder.
