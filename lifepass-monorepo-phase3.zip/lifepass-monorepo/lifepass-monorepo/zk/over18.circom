// over18.circom
// Predicate: Prove that birth year hashed with a secret salt yields a value that corresponds to an age ≥18.
// Inputs: birth_year_hash (private), current_year (public)
// Output: is_over_18 (public boolean)

pragma circom 2.1.6;
include "circomlib/circuits/comparators.circom";

template Over18() {
    // Private input: hash of the birth year (we assume the hash preimage proves the user knows the birth year)
    signal input birth_year_hash;
    // Public input: current year
    signal input current_year;
    // Public output: whether the user is over 18
    signal output is_over_18;

    // For simplicity, we model the age check as current_year - birth_year >= 18.
    // In a real circuit, you'd supply the birth year as a private input and compute the difference.

    // Placeholder: always output true (to be implemented).
    is_over_18 <== 1;
}

component main = Over18();
