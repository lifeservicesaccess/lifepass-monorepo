# LifePass Documentation

This directory contains markdown files and configuration for generating developer and user documentation.

## Setup

You can use MkDocs or Docusaurus. For MkDocs:

```bash
pip install mkdocs-material
mkdocs serve
```
