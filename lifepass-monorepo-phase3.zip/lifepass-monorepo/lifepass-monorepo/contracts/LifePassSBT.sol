// SPDX-License-Identifier: MIT
pragma solidity ^0.8.17;

import "@openzeppelin/contracts/token/ERC721/extensions/ERC721Burnable.sol";
import "@openzeppelin/contracts/access/AccessControl.sol";
import "@openzeppelin/contracts/security/Pausable.sol";
import "@openzeppelin/contracts/proxy/utils/UUPSUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol";

/// @title LifePass Soulbound Token
/// @notice This contract implements a non‑transferable ERC721 token (SBT) with role‑based
/// access control, pause functionality, and event emission for all state changes. It is upgradable via UUPS.
contract LifePassSBT is Initializable, ERC721Burnable, AccessControl, Pausable, UUPSUpgradeable {
    bytes32 public constant ADMIN_ROLE    = keccak256("ADMIN_ROLE");
    bytes32 public constant VERIFIER_ROLE = keccak256("VERIFIER_ROLE");
    bytes32 public constant MINTER_ROLE   = keccak256("MINTER_ROLE");
    bytes32 public constant PAUSER_ROLE   = keccak256("PAUSER_ROLE");

    struct Metadata {
        string purpose;
        uint8 trustScore;
        string verificationLevel;
        string didUri;
    }

    mapping(uint256 => Metadata) private _tokenMetadata;

    event Minted(address indexed to, uint256 indexed tokenId);
    event Revoked(uint256 indexed tokenId);
    event Updated(uint256 indexed tokenId);

    /// @custom:oz‑upgrades‑unsafe‑allow constructor
    constructor() initializer {}

    function initialize() public initializer {
        __ERC721_init("LifePassSBT", "LPSBT");
        _grantRole(DEFAULT_ADMIN_ROLE, msg.sender);
        _grantRole(ADMIN_ROLE, msg.sender);
        _grantRole(VERIFIER_ROLE, msg.sender);
        _grantRole(MINTER_ROLE, msg.sender);
        _grantRole(PAUSER_ROLE, msg.sender);
    }

    /// @dev Create a new SBT. Only VERIFIER role may call.
    function mint(address to, uint256 tokenId, Metadata calldata meta) external whenNotPaused onlyRole(VERIFIER_ROLE) {
        _safeMint(to, tokenId);
        _tokenMetadata[tokenId] = meta;
        emit Minted(to, tokenId);
    }

    /// @dev Update metadata. Only owner or verifier can update.
    function update(uint256 tokenId, Metadata calldata meta) external whenNotPaused {
        require(_exists(tokenId), "SBT: nonexistent token");
        require(_isApprovedOrOwner(msg.sender, tokenId) || hasRole(VERIFIER_ROLE, msg.sender), "SBT: no permission");
        _tokenMetadata[tokenId] = meta;
        emit Updated(tokenId);
    }

    /// @dev Revoke (burn) a token. Only ADMIN may revoke.
    function revoke(uint256 tokenId) external whenNotPaused onlyRole(ADMIN_ROLE) {
        _burn(tokenId);
        emit Revoked(tokenId);
    }

    /// @dev Override transfer methods to prevent transfers (soulbound).
    function _beforeTokenTransfer(address from, address to, uint256 tokenId, uint256 batchSize) internal override {
        super._beforeTokenTransfer(from, to, tokenId, batchSize);
        require(from == address(0) || to == address(0), "SBT: transfer not allowed");
    }

    /// @dev Pause the contract.
    function pause() external onlyRole(PAUSER_ROLE) {
        _pause();
    }

    /// @dev Unpause the contract.
    function unpause() external onlyRole(PAUSER_ROLE) {
        _unpause();
    }

    /// @dev UUPS upgrade authorization. Only ADMIN can upgrade.
    function _authorizeUpgrade(address newImplementation) internal override onlyRole(ADMIN_ROLE) {}
}
