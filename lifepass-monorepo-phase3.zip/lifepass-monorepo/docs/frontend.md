# Frontend Guide

This document provides instructions for running and extending the LifePass web interface.

## Web (Next.js)

The web client is located under `apps/web`.  It uses Next.js and React to provide a simple interface for submitting a zero‑knowledge proof and minting a LifePass SBT.

### Running the Web App

1. Navigate to the `apps/web` directory.
2. Install dependencies:

   ```bash
   npm install
   ```

3. Start the development server:

   ```bash
   npm run dev
   ```

4. Visit `http://localhost:3000` in your browser.

The web app expects the backend API to be reachable at the same origin.  If the API is running on a different port, configure a proxy or update the axios base URL in `pages/index.js`.

### Extending the Interface

Future enhancements include:

- Integrating WalletConnect or MetaMask to automatically populate the wallet address and sign transactions.
- Providing a UI for generating the zero‑knowledge proof (e.g., collecting birth date and computing witness inputs in the browser).
- Displaying the user’s minted LifePass tokens and verification level.

## Mobile (React Native)

The mobile client under `apps/mobile` is a placeholder React Native app.  To run it, set up a React Native environment with Expo or the React Native CLI and install the dependencies defined in `apps/mobile/package.json`.  Future work should mirror the functionality of the web client and integrate native wallet connectors.